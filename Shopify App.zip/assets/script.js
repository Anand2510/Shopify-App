$(document).ready(function() {
    var firstMenuItem = $('.mega-menu__list a').first();
    var firstMenuTitle = firstMenuItem.text().trim();
    $('.image-gap.' + firstMenuTitle).addClass('current');

    $('.mega-menu__list a').hover(function() {
        $('.image-gap').removeClass('current');
 
        var menuTitle = $(this).text().trim();
        $('.image-gap.' + menuTitle).addClass('current');
    });


  let items = document.querySelector(".header__inline-menu").querySelectorAll("details");
  console.log(items)
  items.forEach(item => {
    item.addEventListener("mouseover", () => {
      item.setAttribute("open", true);
      item.querySelector("ul").addEventListener("mouseleave", () => {
        item.removeAttribute("open");
      });
    item.addEventListener("mouseleave", () => {
      item.removeAttribute("open");
    });
  });
  
  });
});


// $(document).ready(function(){
//     // $('.mega-menu__list a').on('click', function(){
//       $('.mega-menu__list a').hover(function(){
//         $('.image-gap').removeClass('current');
        
//         var menuTitle = $(this).text().trim();
//         $('.image-gap.' + menuTitle).addClass('current');
//     });
// });

// $(document).ready(function(){
//     $('.mega-menu__list').on('click', function(){
//   // $('.mega-menu__list').hover(function(){
//     $('.image-gap').toggleClass('current');
//   });
// });
$(function() {
  // Owl Carousel
  var owl = $(".owl-carousel");
  owl.owlCarousel({
    items: 3,
    margin: 10,
    loop: true,
    nav: true
  });
});

  // let swiper = new Swiper(".mySwiper", {
  //   slidesPerView: "auto",
  //   spaceBetween: 12,
  //   pagination: {
  //     el: ".swiper-pagination",
  //     type: "progressbar",
  //   },
  //   navigation: {
  //     nextEl: ".swiper-button-next",
  //     prevEl: ".swiper-button-prev",
  //   },
  //   autoplay: {
  //     delay: 3000,
  //     disableOnInteraction: false,
  //   },
  // });


    let swiper = new Swiper(".mySwiper", {
  slidesPerView: "auto",
  spaceBetween: 12,
  pagination: {
    el: ".swiper-pagination",
    type: "progressbar"
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev"
  }
});